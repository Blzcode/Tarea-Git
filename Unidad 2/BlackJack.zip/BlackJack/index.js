
Boolean

function IntegerRandom(limite){
    return Math.floor(Math.random()*limite);

}


var carta1=IntegerRandom(12), carta2=IntegerRandom(12), cartacpu1=IntegerRandom(12), cartacpu2=(12);


alert('Bienvenido a BLACKJACK!');
alert('El valor de su primera carta es '+ carta1);
alert('El valor de su segunda carta es '+ carta2);
blackjackusuario= carta1+carta2;
blackjackcpu= cartacpu1+ cartacpu2;




while (blackjackusuario<=21&&blackjackcpu<=21){

    alert('Su total es '+blackjackusuario);

    if (blackjackusuario==21 && blackjackcpu==21){

        alert('El juego es un empate :(');
    
    }
else if (blackjackusuario==21 && blackjackcpu!=21){

    alert('HAS GANADO!');

}

else if (blackjackusuario!=21 && blackjackcpu==21){

    alert('El total de la casa es '+ blackjackcpu+' La Casa gana!');
}


    else if(blackjackusuario<21 && blackjackcpu<21){
              var otra= prompt("Desea Sacar otra Carta? S/N");

               
                
              if (otra=="S" || otra=="s") {

                blackjackusuario=blackjackusuario+IntegerRandom(12);

                

                if (blackjackcpu<blackjackusuario &&blackjackusuario<=21) {
                    blackjackcpu=blackjackcpu+IntegerRandom(12);
                    }

                    if(blackjackusuario>blackjackcpu&&blackjackusuario<=21){
                        alert('Su nuevo total es ' +blackjackusuario);
                        alert('El total de la casa es '+ blackjackcpu+' Usted ha ganado!');
                    }
    
                     else if(blackjackcpu>blackjackusuario&&blackjackcpu<=21)
                     {
                        alert('Su nuevo total es ' +blackjackusuario);
                        alert('El total de la casa es '+ blackjackcpu+' La Casa gana!');
                    }
              }

              if (otra=="N" || otra=="n") {
                
                alert('El total de la casa es ' + blackjackcpu);

                if(blackjackusuario>blackjackcpu){
                    alert('El total de la casa es '+ blackjackcpu+' Usted ha ganado!');
                }

                 else if(blackjackcpu>blackjackusuario)
                 {
                    alert('El total de la casa es '+ blackjackcpu+' La Casa gana!');
                }
              }

    }

    

}

if(blackjackusuario>21&& blackjackcpu<=21){

    alert("Su total es "+ blackjackusuario+"-- Gana la casa! --  ")
}

else if (blackjackcpu>21&& blackjackusuario<=21){

    alert("El total de la casa es "+ blackjackcpu+"-- HA GANADO! --  ")
}









