var día = prompt ('Inrese su día de nacimiento');
var mes = prompt ('Ingrese su mes de nacimiento en números');


if (mes==12)  
{
    if (día>21){

    
    alert("Usted es un Capricornio");
}
else alert("Usted es un Sagitario");
}

if (mes==1)  
{
    if (día>20){

    
    alert("Usted es un Acuario");
}
else alert("Usted es un Capricornio");
}

if (mes==2)  
{
    if (día>19){

    
    alert("Usted es un Piscis");
}
else alert("Usted es un Acuario");
}

if (mes==3)  
{
    if (día>20){

    
    alert("Usted es un Aries");
}
else alert("Usted es un Piscis");
}

if (mes==4)  
{
    if (día>20){

    
    alert("Usted es un Tauro");
}
else alert("Usted es un Aries");
}

if (mes==5)  
{
    if (día>20){

    
    alert("Usted es un Geminis");
}
else alert("Usted es un Tauro");
}

if (mes==6)  
{
    if (día>20){

    
    alert("Usted es un Cancer");
}
else alert("Usted es un Geminis");
}

if (mes==7)  
{
    if (día>22){

    
    alert("Usted es un Leo");
}
else alert("Usted es un Cancer");
}

if (mes==8)  
{
    if (día>23){

    
    alert("Usted es un Virgo");
}
else alert("Usted es un Leo");
}

if (mes==9)  
{
    if (día>22){

    
    alert("Usted es un Libra");
}
else alert("Usted es un Virgo");
}

if (mes==10)  
{
    if (día>23){

    
    alert("Usted es un Escorpio");
}
else alert("Usted es un Libra");
}
if (mes==11)  
{
    if (día>22){

    
    alert("Usted es un Sagitario");
}
else alert("Usted es un Escorpio");
}